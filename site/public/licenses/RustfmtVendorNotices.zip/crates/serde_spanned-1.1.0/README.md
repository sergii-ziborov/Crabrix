# serde_spanned

[![Documentation](https://img.shields.io/badge/docs-master-blue.svg)](https://docs.rs/serde_spanned)
![License](https://img.shields.io/crates/l/serde_spanned.svg)
[![Crates Status](https://img.shields.io/crates/v/serde_spanned.svg)](https://crates.io/crates/serde_spanned)

A [serde]-compatible spanned Value

This allows capturing the location, in bytes, for a value in the original parsed document for
compatible deserializers.

[serde]: https://serde.rs/

## License

Licensed under either of

* Apache License, Version 2.0, ([LICENSE-APACHE](LICENSE-APACHE) or <https://www.apache.org/licenses/LICENSE-2.0>)
* MIT license ([LICENSE-MIT](LICENSE-MIT) or <https://opensource.org/license/mit>)

at your option.

### Contribution

Unless you explicitly state otherwise, any contribution intentionally
submitted for inclusion in the work by you, as defined in the Apache-2.0
license, shall be dual-licensed as above, without any additional terms or
conditions.
